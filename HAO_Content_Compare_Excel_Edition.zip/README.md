# HÀO Content Compare — Excel Edition 1.1

Ứng dụng web tĩnh bằng HTML, CSS và JavaScript để phân tích và so sánh hiệu suất nội dung số theo nhóm KPI 1.2–1.12. Có thể chạy trực tiếp trên trình duyệt hoặc triển khai miễn phí bằng GitHub Pages.

## Tính năng

- Dashboard: Reach, Impression, Engagement, Clicks, Conversions, biểu đồ và các phát hiện chính.
- So sánh hai nội dung bất kỳ theo KPI; hiển thị chênh lệch và xếp hạng toàn bộ nội dung.
- Quản lý dữ liệu: thêm, sửa, xóa, tìm kiếm và sắp xếp nội dung.
- **Nhập trực tiếp Excel (.xlsx/.xls)**: đọc sheet `Du_lieu`, dò tên cột, kiểm tra dữ liệu và cập nhật toàn bộ bộ dữ liệu.
- **Xuất trực tiếp Excel (.xlsx)**: tạo workbook gồm sheet `Du_lieu` (dữ liệu đầu vào + công thức KPI) và `Huong_dan`.
- Nhập/xuất CSV để tương thích thêm với bảng tính khác.
- A/B Testing: so sánh CTR, Conversion Rate và Retention.
- Giải thích Content KPI, Reach, Impression, Engagement, Engagement Rate, CTR, Conversion Rate, Watch Time, Retention, A/B Testing và Content Performance Analysis.
- Lưu dữ liệu trong Local Storage của trình duyệt hiện tại.

## Chạy ứng dụng

1. Giải nén gói ZIP.
2. Mở `index.html` bằng Chrome, Edge hoặc Firefox.
3. Để sử dụng tính năng Excel, thiết bị cần có Internet để tải thư viện SheetJS từ jsDelivr.

## Cấu trúc file

- `index.html`: toàn bộ ứng dụng.
- `mau-du-lieu-noi-dung.xlsx`: workbook Excel mẫu có sẵn 8 nội dung mô phỏng, công thức KPI và hướng dẫn.
- `sample-data.csv`: mẫu CSV tương thích.
- `README.md`: tài liệu triển khai và sử dụng.
- `.nojekyll`: cấu hình GitHub Pages.

## Cách dùng Excel để tự chỉnh dữ liệu trong app

1. Mở app → **Dữ liệu nội dung** → **Xuất Excel (.xlsx)** để sao lưu dữ liệu đang có; hoặc tải file `mau-du-lieu-noi-dung.xlsx`.
2. Mở file bằng Microsoft Excel hoặc Google Sheets.
3. Trong sheet `Du_lieu`, chỉ chỉnh các cột **A:N**: `id`, `date`, `title`, `duration`, `reach`, `impressions`, `likes`, `comments`, `shares`, `saves`, `clicks`, `conversions`, `views`, `avgWatch`.
4. Không chỉnh các cột **O:T** vì đây là công thức tự động: `engagement`, `engagementRate`, `ctr`, `conversionRate`, `watchTimeHours`, `retention`.
5. Muốn thêm nội dung: thêm một dòng ở cuối bảng, điền đủ A:N và đặt `id` duy nhất (ví dụ `ND09`). Muốn xóa nội dung: xóa cả dòng tương ứng, không xóa dòng tiêu đề.
6. Giữ nguyên tên 14 tiêu đề đầu vào. Ngày đăng nên theo dạng `YYYY-MM-DD`, ví dụ `2026-10-13`. Các cột số phải là số không âm; `duration` phải lớn hơn 0.
7. Lưu file dưới dạng **Excel Workbook (.xlsx)**.
8. Quay lại app → **Dữ liệu nội dung** → **Nhập Excel (.xlsx)** → chọn file vừa lưu.
9. Xác nhận nhập. App thay thế toàn bộ dữ liệu hiện tại bằng các dòng trong sheet `Du_lieu`, tính lại KPI, cập nhật dashboard và bảng so sánh, rồi lưu trong trình duyệt.

**Quan trọng:** Vì import Excel thay thế toàn bộ dữ liệu, hãy giữ lại tất cả dòng bạn muốn tiếp tục sử dụng. Luôn xuất một bản sao lưu trước khi chỉnh sửa. Dữ liệu lưu trong trình duyệt trên thiết bị hiện tại; không tự đồng bộ sang máy khác.

## Công thức KPI đang dùng

- Engagement = Likes + Comments + Shares + Saves
- Engagement Rate = Engagement / Reach
- CTR = Clicks / Impressions
- Conversion Rate = Conversions / Clicks
- Watch Time (giờ) = Views × Avg Watch Time (giây) / 3.600
- Retention = Avg Watch Time / Duration

Ứng dụng tính lại các KPI từ 14 cột đầu vào; không phụ thuộc các giá trị công thức được lưu trong Excel. Các định nghĩa có thể khác nhau theo nền tảng, nên cần thống nhất cách đo khi so sánh.

## Triển khai lên GitHub Pages

1. Đăng nhập GitHub và tạo repository mới, ví dụ `hao-content-compare`.
2. Chọn Public rồi tạo repository.
3. Giải nén ZIP trên máy tính.
4. Vào repository → **Add file → Upload files**.
5. Mở thư mục `hao-content-compare` đã giải nén; tải **các file bên trong thư mục** lên thư mục gốc của repository (không tạo thêm một thư mục con cùng tên trong repository).
6. Commit changes.
7. Vào **Settings → Pages**.
8. Trong **Build and deployment**, chọn **Deploy from a branch**.
9. Chọn branch `main`, folder `/(root)`, nhấn **Save**.
10. Sau khi Pages hoàn tất, app có địa chỉ dạng `https://TEN-GITHUB.github.io/hao-content-compare/`.

## Dữ liệu thực hành

Bộ ND01–ND08 mô phỏng chiến dịch video bán quần áo từ 05–12/10/2026. Đây là dữ liệu giả lập để học tập, không phải số liệu lấy từ tài khoản quảng cáo hay thương hiệu thật. Reach cộng giữa nhiều bài không đồng nghĩa số người duy nhất của toàn chiến dịch.
